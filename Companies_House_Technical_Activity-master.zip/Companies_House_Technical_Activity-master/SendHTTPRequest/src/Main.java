/*
 ------- Companies House Code Test
 ------- Developer: Jake Garner
 ------- Version: 2.0
 ------- Description: 'GET' & 'POST' request for Video game information using json data file
 ------- Other Info: This project is using 'npm run json:server'
*/

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.*;



public class Main {

    private  static  HttpURLConnection connection;


    public static void main(String[] args)
    {
        BufferedReader reader;
        String line;
        StringBuffer response = new StringBuffer();

        try {
            URL url = new URL("http://localhost:3000/Games");

            // Setup connection to web address and declare request method 'GET'
            connection = (HttpURLConnection) url.openConnection();

            connection.setRequestMethod("GET");
            connection.setConnectTimeout(5000);
            connection.setReadTimeout(5000);

            int status = connection.getResponseCode();


            // Part 1
            // Check response from connection
            // If connection status is not 200 Ok, then read the ErrorStream using reader and response
            // Else 200 OK read InputStream
            if(status > 299)
            {
                reader = new BufferedReader(new InputStreamReader(connection.getErrorStream()));
                while((line = reader.readLine()) !=null)
                {
                    response.append(line);
                }
                reader.close();
            }else
            {
                reader  = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                while ((line = reader.readLine()) !=null)
                {
                    response.append(line);
                }
                reader.close();
            }

            // Display response value
            System.out.println("GET response \n" + response.toString());
            // Call parse class passing in response string
            String jsonResults = parse(response.toString());

            // Part 2
            // Call post class passing in jsonResults string
            // json string returned from 'parse'
            post(jsonResults);

            // Catch exceptions
            // Finally make sure to disconnect
        } catch (IOException e) {
            e.printStackTrace();
        }finally
        {
            connection.disconnect();
        }
    }

    // 'parse' Class that takes the value from the get request and extracts the information required for part 2
    // Extracts: Average likes per game, user with most comments, and game with highest amount of likes

    public static String parse(String responseInfo)
    {
        JSONArray games = new JSONArray(responseInfo);
        String likesPerGame = "";
        int highestLikes = 0;
        String eachUser = "";
        String [] commentCount;
        String highestRatedGame ="";
        List<String> avgLikesArr = new ArrayList<>();

        for (int i = 0; i < games.length(); i++)
        {
            JSONObject game = games.getJSONObject(i);

            // Gets node values for each of the below
            String title = game.getString("title");
            int likes = game.getInt("likes");

            // Comment nodes contains multiple values
            // Put node into a string array, then loop for each value in array.
            // Using string splitting and replaceAll methods
            JSONArray arrayNode = (JSONArray) game.get("Comments");
            String getUserName;
            String[] likePerUserArray;
            String[] likePerUser;


            int avgLikesPerGame = 0;
            int counter = 0;

            String[] uniqueUserName;

            // Loop for amount of values in array to extract individual users per game
            for (Object userName : arrayNode) {
                if (userName == "" || userName == null) {

                } else
                    {
                    counter++;
                    getUserName = userName.toString();
                    uniqueUserName = getUserName.split("user");

                    likePerUserArray = uniqueUserName[0].split("message");
                    likePerUser = likePerUserArray[0].split("like");
                    likePerUser[1] = likePerUser[1].replaceAll("[^a-zA-Z0-9]", "");

                    eachUser = eachUser + uniqueUserName[1] +", ";

                    avgLikesPerGame = avgLikesPerGame + Integer.parseInt(likePerUser[1]);

                    }

            }

            // Find Game with the highest likes
            if(likes > highestLikes)
            {
                highestLikes = likes;
                highestRatedGame = title;
            }

            // Get the average likes per game
            avgLikesPerGame = avgLikesPerGame / counter;
            eachUser = eachUser.replaceAll("[^a-zA-Z0-9,]", "");

            if(i== games.length()-1){
                avgLikesArr.add("{" + "\n\"title\": \"" +title + "\",\n" +"\"average_likes\": \"" + avgLikesPerGame +"\"}");
            }
            else{
                avgLikesArr.add("{" + "\n\"title\": \"" +title + "\",\n" +"\"average_likes\": \"" + avgLikesPerGame +"\"},");
            }




        }

        // Find the user with the most comments from all the games
        // User hashmap to get the total count of each unique value in array
        // Then check each value count against each other to find the highest user comments
        commentCount = eachUser.split(",");
        Map<String,Integer> hm = new HashMap();
        for(String x:commentCount){

            if(!hm.containsKey(x)){
                hm.put(x,1);
            }else{
                hm.put(x, hm.get(x)+1);
            }

        }
        String highestUserComment = "";
        int highestVal = 0;
        for (String s : hm.keySet()) {
            if(hm.get(s) > highestVal) {
                highestVal = hm.get(s);
                highestUserComment = s;
            }

        }

        for(int i=0; i<avgLikesArr.size(); i++)
        {
            likesPerGame = likesPerGame + avgLikesArr.get(i);
        }
        // Add the values to json string that will be used for the 'post' request
        String jsonResults = "{\n \"ID\": 1,\r\n" +
                "    \"user_with_most_comments\": \"" +highestUserComment + "\",\r\n" +
                "    \"highest_rated_game\": \"" + highestRatedGame + "\",\r\n" +
                "    \"average_likes_per_game\":[ " + likesPerGame + "\n]}";

        //System.out.println( "Before return: \n" + jsonResults);
        return jsonResults;
    }


    // Class for the 'POST' request using the jsonResults string from 'parse class'

    public static String post(String jsonInfo) {
        try {

             final String POST_PARAMS = jsonInfo;

            URL obj = new URL("http://localhost:3000/Reports");

            // Set up connection to web page and declare request method as 'POST'
            HttpURLConnection postConnection = (HttpURLConnection) obj.openConnection();
            postConnection.setRequestMethod("POST");

            postConnection.setRequestProperty("Content-Type", "application/json");
            postConnection.setDoOutput(true);
            OutputStream os = postConnection.getOutputStream();

            os.write(POST_PARAMS.getBytes());
            os.flush();
            os.close();

            int responseCode = postConnection.getResponseCode();
            // Print response code and message
            System.out.println("POST Location:" + obj);
            java.awt.Desktop.getDesktop().browse(obj.toURI());
            System.out.println("POST Response Code :  " + responseCode);
            System.out.println("POST Response Message : " + postConnection.getResponseMessage());

            // If response code is 'created' then success, then add response value to 'response' and print
            // Else print error / didnt work
            if (responseCode == HttpURLConnection.HTTP_CREATED)
                { //success
                BufferedReader in = new BufferedReader(new InputStreamReader(
                        postConnection.getInputStream()));
                String inputLine;
                StringBuffer response = new StringBuffer();
                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();
                // print result
                System.out.println(response.toString());
            } else
                {
                System.out.println("POST NOT WORKED");
                }
        } catch (Exception e)
        {
        }
        // Return nothing
       return null;
    }
}
